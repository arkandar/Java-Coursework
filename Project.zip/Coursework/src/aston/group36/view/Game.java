package aston.group36.view;
import java.util.ArrayList;

import aston.group36.IO.FileReader;
import aston.group36.model.Board;
import aston.group36.model.Player;
/**
 * 
 * Stores the board and has a basic TUI
 * 
 * @author Iqbal Miah
 * @version 1.0
 *
 */
public class Game {
	
	protected Board board;	
	protected ArrayList<Player> players;
	protected boolean gameWon;
	private int round;
	private int numPlayers;
	private FileReader reader;
	
	public Game(){
		// TODO 
	}
	
	public void placePlayer(Player p){
		// TODO 
	}
	
	public void incrementRound(){
		round++;
	}
	
	public void startGame(){
		// TODO 
	}
	
	public void winGame(Player p){
		// TODO 
	}
}
