package aston.group36.view;

import aston.group36.model.Board;

public class TextView  {
	private Board board;
	public TextView() {
		
        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                grid[row][col] = new Pit();
            }
        }
        
		Entity gear1 = new Gear();
		this.place(gear1, 2, 3);

		Entity gear2 = new Gear();
		this.place(gear2, 1, 3);

		Robot robot = new Robot();
		this.place(robot, 3, 0);

		for (int row = 0; row < grid.length; row++) {
			for (int col = 0; col < grid[row].length; col++) {
				System.out.print(grid[row][col].toString() + "\t");
			}
			System.out.println();*/
		}
	}

}
