package aston.group36.model;
/**
 * 
 * Robot is the object the player controls
 * 
 * @author Muhammad Yusuf
 * @version 1.0
 *
 */
public class Robot{

	public Location loc;
	public Player player;
	
	public Robot(){
		// TODO 
	}
	public void act(Action a) {

	}
	
	public Location getLocation() {
		return loc;

	}

	public void destroy() {
		// TODO 
	}

	public void push() {
		// TODO 
	}

	public Location getStartingLocation() {
		// TODO 
		return null;
	}
	
	public String toString() {
		// TODO 
		return null;
	}
}
