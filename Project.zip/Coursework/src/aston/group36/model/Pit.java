package aston.group36.model;
/**
 * 
 * Destroys the Robots 
 * 
 * @author Asaa Umar
 * @version 1.0
 *
 */
public class Pit extends Entity {
	public Pit() {
		// TODO 
	}


	@Override
	public void react(Robot r) {
		// TODO Auto-generated method stub
		
	}
}
