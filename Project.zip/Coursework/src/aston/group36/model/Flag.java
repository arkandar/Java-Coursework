package aston.group36.model;
/**
 * 
 * Element that player must interact with to win
 * 
 * @author Khawaja Ahmad
 * @version 1.0
 *
 */
public class Flag extends Entity  {
		
	public Flag() {
		// TODO 
	}
	
	public void notifyGame() {
		// TODO 
	}

	@Override
	public void react(Robot r) {
		// TODO Auto-generated method stub
		
	}
}
