package aston.group36.model;
/**
 * 
 * Stores an 2D Object Array with methods to fill the board and print it to console
 * 
 * @author Muhammad Yusuf, Iqbal Miah, Asaa Umar 
 * @version 1.0
 *
 */
public class Board {

	public Object[][] grid;

	public Board(int x, int y){
		// TODO 

	}

	public void activate(){
		// TODO 
	}

	public void place(Object o,int x,int y){
		grid[x][y] = o;
	}
	public Location getAdjacentLocation() {
		// TODO 
		return null;
	}

}