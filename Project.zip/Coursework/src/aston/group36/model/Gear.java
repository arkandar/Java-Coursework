package aston.group36.model;
/**
 * 
 * Rotates Player
 * 
 * @author Enamul Rahman
 * @version 1.0
 *
 */
public class Gear extends Entity{
	public Gear() {
		// TODO 
	}

	
	@Override
	public void react(Robot r) {
		// TODO Auto-generated method stub
		
	};

}
