package aston.group36.IO;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReader {
	private static String filename;
	public FileReader(String f) {
		filename = f;
	}
	
	private static void readFile(String fileName) throws FileNotFoundException {
		try(Scanner scanner = new Scanner(new File(filename))){
			scanner.useDelimiter(System.getProperty("line.seperator"));
			while (scanner.hasNext());
		}
	}

}
